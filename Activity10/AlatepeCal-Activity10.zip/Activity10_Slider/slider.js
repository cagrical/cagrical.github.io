$(document).ready(function() {
        	$("#slider").bxSlider({
			  auto: true,
			  minSlides: 1,
			  maxSlides: 1,
			  captions:true,
			  randomStart: true,
			  slideWidth: 250,
			  slideMargin: 10,
			  pause:3000,
			  pagerType:'short'
			});
    	});